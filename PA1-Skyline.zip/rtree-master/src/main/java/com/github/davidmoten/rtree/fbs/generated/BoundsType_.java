// automatically generated, do not modify

package com.github.davidmoten.rtree.fbs.generated;

public final class BoundsType_ {
  private BoundsType_() { }
  public static final byte BoundsFloat = 0;
  public static final byte BoundsDouble = 1;

  private static final String[] names = { "BoundsFloat", "BoundsDouble", };

  public static String name(int e) { return names[e]; }
};

