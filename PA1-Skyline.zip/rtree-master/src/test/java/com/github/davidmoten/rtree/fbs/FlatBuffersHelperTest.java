package com.github.davidmoten.rtree.fbs;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class FlatBuffersHelperTest {

    @Test
    public void isUtilityClass() {
        Asserts.assertIsUtilityClass(FlatBuffersHelper.class);
    }

}
