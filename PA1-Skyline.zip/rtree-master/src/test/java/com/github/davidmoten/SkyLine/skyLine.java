package com.github.davidmoten.SkyLine;

import com.github.davidmoten.rtree.*;
import com.github.davidmoten.rtree.geometry.*;
import com.github.davidmoten.rtree.geometry.Point;
import com.github.davidmoten.rtree.internal.EntryDefault;
import com.github.davidmoten.rtree.internal.util.PriorityQueue;
import com.sun.java.swing.action.AboutAction;

import org.apache.commons.math3.dfp.DfpMath;
import org.mockito.internal.util.reflection.GenericMaster;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.List;    

public class skyLine {
    private List<Entry<Object,Point>> skyLinePt;//for storing the skyline points
    private RTree<String,Point> tree;//R Tree
    PriorityQueue<HasGeometry> pq;//For storing and sorting the points and MBR
    private List<Point> points;//Storing all the points
    private Map<Point, PriorityQueue<HasGeometry>> dom_area;

    //compare the distance(X+Y) between different points
    private class distanceComparator implements Comparator<HasGeometry>{
        @Override
        public int compare(HasGeometry o1, HasGeometry o2) {
            double d1=o1.geometry().mbr().x1()+o1.geometry().mbr().y1();
            double d2=o2.geometry().mbr().x1()+o2.geometry().mbr().y1();
            if(d1>d2){
                return 1;
            }
            else if(d1<d2){
                return -1;
            }else{
                return 0;
            }
        }
    }

    //constructor
    public skyLine() throws IOException {
        tree=buildTree();
        skyLinePt=new ArrayList<Entry<Object, Point>>();
        pq=new PriorityQueue<HasGeometry>(new distanceComparator());
        dom_area = new HashMap<Point,PriorityQueue<HasGeometry>>();
    }

    //build the tree using the points from the greek-earthquakes-1964-2000.txt
    public RTree<String ,Point> buildTree() throws IOException {
        tree = RTree.create();
        List<Point> pts=getData();
        String item="point";
        points=pts;
        for(Point pt:pts){
            tree=tree.add(item,pt);
        }
        // List<Point> pts = new ArrayList<Point>();
        // pts.add(Geometries.point(1,9));
        // pts.add(Geometries.point(2,10));
        // pts.add(Geometries.point(4,8));
        // pts.add(Geometries.point(6,7));
        // pts.add(Geometries.point(9,10));
        // pts.add(Geometries.point(7,5));
        // pts.add(Geometries.point(5,6));
        // pts.add(Geometries.point(4,3));
        // pts.add(Geometries.point(3,2));
        // pts.add(Geometries.point(10,4));
        // pts.add(Geometries.point(9,1));
        // pts.add(Geometries.point(6,2));
        // pts.add(Geometries.point(8,3));
        // points=pts;

        // tree = tree.add("a", Geometries.point(1,9));
        // tree = tree.add("b", Geometries.point(2,10));
        // tree = tree.add("c", Geometries.point(4,8));
        // tree = tree.add("d", Geometries.point(6,7));
        // tree = tree.add("e", Geometries.point(9,10));
        // tree = tree.add("f", Geometries.point(7,5));
        // tree = tree.add("g", Geometries.point(5,6));
        // tree = tree.add("h", Geometries.point(4,3));
        // tree = tree.add("i", Geometries.point(3,2));
        // tree = tree.add("j", Geometries.point(10,4));
        // tree = tree.add("k", Geometries.point(9,1));
        // tree = tree.add("m", Geometries.point(6,2));
        // tree = tree.add("n", Geometries.point(8,3));
        tree.visualize(300,300).save("mytree.png");
        return tree;
    }

    //find skyline points
    public void findSkyLine(){
        Node root=tree.root().get();
        pq.add(root);
        //loop until the queue is empty
        while(!pq.isEmpty()){
            HasGeometry node=pq.poll();
            //situation when the current node is not an entry
            if(node instanceof Node) {
                //situation when the current node is not a leaf mbr
                if (node instanceof NonLeaf) {
                    for (Node<Object, Point> child : ((NonLeaf<Object, Point>) node).children()) {
                        pq.add(child);
                    }
                }
                //situation when the current node is a leaf mbr
                else {
                    /* if current node is leaf mbr
                     * then add leaves(entries) to priority queue
                     * */
                    for (Entry<Object, Point> leaf : ((Leaf<Object, Point>) node).entries()) {
                        pq.add(leaf);
                    }
                }
            }
            //situation when the current node is an entry
            else{
                if(ifSkyLinePt(node)){
                    skyLinePt.add(((Entry<Object,Point>)node));
                    prune(node);
                }
            }
        }

        //sort the skyline point result
        sorting();
    }

    //judge whether is a skyline point
    private boolean ifSkyLinePt(HasGeometry node){
        double x=node.geometry().mbr().x1();
        double y=node.geometry().mbr().y1();
        for(Entry<Object,Point>pointEntry:skyLinePt){
            if(isDominated(pointEntry.geometry().x(),pointEntry.geometry().y(),x,y)){
                return false;
            }
        }
        return true;
    }

    //prune the mbr/point which is dominated by pts in skyline points
    private void prune(HasGeometry node){
        Iterator<HasGeometry> iterator=pq.iterator();
        PriorityQueue<HasGeometry> dom_pq;
        dom_pq = new PriorityQueue<HasGeometry>(new distanceComparator());
        double y=node.geometry().mbr().y1();
        double x=node.geometry().mbr().x1();
        while(iterator.hasNext()){
            HasGeometry n=iterator.next();
            double x1=n.geometry().mbr().x1();
            double y1=n.geometry().mbr().y1();
            if(isDominated(x,y,x1,y1)){
                dom_pq.add(n);
                iterator.remove();
            }
        }
        dom_area.put(Geometries.point(x,y),dom_pq);
    }

    //judge whether point 1(x1,y1) is dominated by point 2(x2,y2)
    private boolean isDominated(double x1,double y1, double x2,double y2){return x1<=x2&&y1<=y2;}

    //sort comparator according to points' x value
    private class sortingComparator implements Comparator<Entry<Object,Point>>{

        @Override
        public int compare(Entry<Object, Point> o1, Entry<Object, Point> o2) {
            double x1 = o1.geometry().mbr().x1();
            double x2 = o2.geometry().mbr().x1();
            if(x1 > x2){
                return 1;
            }
            else if(x1 < x2){
                return -1;
            }
            else{
                return 0;
            }
        }
    }

    //for sorting the skyline points
    private void sorting(){
        Collections.sort(skyLinePt, new sortingComparator());
    }

    //retrieve and parse the data from the text file, store in a list
    private List<Point> getData() throws IOException {
        // String path = this.getClass().getResource("").getPath();
        // path = path.replace("file:", "");
        // File file = new File(path+FileStr);
        String path = "src/test/java/com/github/davidmoten/SkyLine/test.txt";
        File file = new File(path);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        List<Point> res=new ArrayList<Point>();
        int count=0;
        while ((st = br.readLine()) != null&&count<200){
            st=st.replace("\n","");
            String[] sts=st.split(" ");
            res.add(Geometries.point(Double.parseDouble(sts[0]),Double.parseDouble(sts[1])));
            count++;
        }
        return res;
    }
    //visualize the skyline and points
    public void visualize() throws IOException {
        //build an image with height of 5000 and width of 8000
        int width = 8000, height = 5000;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);
        Graphics2D graphics = image.createGraphics();
        graphics.setColor(Color.BLACK);
        graphics.setBackground(Color.BLUE);
        graphics.translate(0, height);
        graphics.scale(1,-1);

        //visualize the points
        for(Point pt:points){
            int x = (int)(pt.x() * 100);
            int y = (int)(pt.y() * 100);
            graphics.fillOval(x, y,10,10);
        }
        //visualize all the skylines
        for(int i = 0; i < skyLinePt.size(); ++i){

            Point point = skyLinePt.get(i).geometry();
            int x = (int)(point.x() * 100);
            int y = (int)(point.y() * 100);
            graphics.fillOval(x, y,10,10);

            if (i == 0){
                graphics.drawLine(x, height, x, y);
            }else {
                Point previous = skyLinePt.get(i - 1).geometry();
                int previousY = (int)(previous.y() * 100);
                graphics.drawLine(x, previousY, x, y);
            }

            if (i == skyLinePt.size() - 1){
                graphics.drawLine(x, y, width, y);
            }else {
                Point next = skyLinePt.get(i + 1).geometry();
                int nextX = (int)(next.x() * 100);
                graphics.drawLine(x, y, nextX, y);
            }
        }
        graphics.dispose();
        //store as png image
        ImageIO.write(image, "png", new File("skyline.png"));
    }

    public void insertion() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("ScannerTest, Please Enter Point Position X Need to Insert:");   
        double insert_point_x = sc.nextDouble();  //get the point position x need to insert.
        System.out.println("ScannerTest, Please Enter Point Position Y Need to Insert:");  
        double insert_point_y = sc.nextDouble();  //get the point position y need to insert.
        boolean flag = true;
        for(int i = 0; i < skyLinePt.size(); i++){
            Point point = skyLinePt.get(i).geometry();
            flag = isDominated(point.x(), point.y(), insert_point_x, insert_point_y);
            if(!flag){
                break;
            }
        }

        boolean d_flag = true;
        if(!flag){
            for(int i = 0; i < skyLinePt.size(); i++){
                Point point = skyLinePt.get(i).geometry();
                d_flag = isDominated(insert_point_x, insert_point_y, point.x(), point.y());
                if(d_flag){
                    skyLinePt.remove(i);
                }
            }
        }   
        String item="point";
        Object obj = item;
        skyLinePt.add(Entries.entry(obj, Geometries.point(insert_point_x, insert_point_y)));
        tree.add(item,Geometries.point(insert_point_x, insert_point_y));
        points.add(Geometries.point(insert_point_x, insert_point_y));
        tree.visualize(300,300).save("mytree.png");
        sorting();
        visualize();
    }

    public void deletion() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("ScannerTest, Please Enter Point Position X Need to delete:");   
        double delete_point_x = sc.nextDouble();  //get the point position x need to delete. 
        System.out.println("ScannerTest, Please Enter Point Position X Need to delete:");   
        double delete_point_y = sc.nextDouble();  //get the point position y need to delete.
        String item = "point";
        Object obj = item;
        if(skyLinePt.contains(Entries.entry(obj, Geometries.point(delete_point_x, delete_point_y)))){
            Iterator<Entry<Object,Point>> it = skyLinePt.iterator();
            while(it.hasNext()){
                Entry<Object,Point> n = it.next();
                if(n.equals(Entries.entry(obj, Geometries.point(delete_point_x, delete_point_y)))){
                    it.remove();
                }
            }
            PriorityQueue<HasGeometry> pq_sub = new PriorityQueue<HasGeometry>(new distanceComparator()); 
            pq_sub = dom_area.get(Geometries.point(delete_point_x, delete_point_y));
            while(!pq_sub.isEmpty()){
                HasGeometry node=pq_sub.poll();
                //situation when the current node is not an entry
                if(node instanceof Node) {
                    //situation when the current node is not a leaf mbr
                    if (node instanceof NonLeaf) {
                        for (Node<Object, Point> child : ((NonLeaf<Object, Point>) node).children()) {
                            pq_sub.add(child);
                        }
                    }
                    //situation when the current node is a leaf mbr
                    else {
                        /* if current node is leaf mbr
                         * then add leaves(entries) to priority queue
                         * */
                        for (Entry<Object, Point> leaf : ((Leaf<Object, Point>) node).entries()) {
                            pq_sub.add(leaf);
                        }
                    }
                }
                //situation when the current node is an entry
                else{
                    if(ifSkyLinePt(node)){
                        skyLinePt.add(((Entry<Object,Point>)node));
                        prune(node);
                    }
                }
            }
        }
        tree.delete(item, Geometries.point(delete_point_x, delete_point_y));
        tree.visualize(300,300).save("mytree.png");
        sorting();
        visualize();
    }
    //the main function
    public static void main(String[] args) throws IOException {
        skyLine sl=new skyLine();
        sl.findSkyLine();
        sl.visualize();
        System.out.println("Do you need to insert a point?\n"); 
        System.out.println("0. No,              1. Yes"); 
        Scanner sc = new Scanner(System.in);
        int ans = sc.nextInt();
        if(1 == ans){
            sl.insertion();       
        }
        System.out.println("Do you need to delete a point?\n"); 
        System.out.println("0. No,              1. Yes"); 
        ans = sc.nextInt();
        if(1 == ans){
            sl.deletion();
        }
    }
}
