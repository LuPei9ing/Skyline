package com.github.davidmoten.rtree;

public enum Precision {

    DOUBLE, SINGLE;

}
